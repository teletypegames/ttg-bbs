A synthetic info pack.
